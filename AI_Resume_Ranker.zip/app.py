import streamlit as st

st.set_page_config(page_title="AI Resume Ranker", layout="centered")

st.title("🤖 Welcome to AI Resume Ranker!")
st.markdown("Choose from the sidebar: Candidate or Recruiter page.")
